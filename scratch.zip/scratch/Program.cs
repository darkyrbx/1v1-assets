using System;
using System.Reflection;
using System.Linq;
using System.Runtime.Loader;

var gameDlls = @"C:\Users\karee\Downloads\1v1LOL-Reloaded-v446-2\1v1LOL-Reloaded\1v1_LOL_Data\Managed";
var allDllPaths = System.IO.Directory.GetFiles(gameDlls, "*.dll")
    .Append(typeof(object).Assembly.Location)
    .ToArray();

var resolver = new PathAssemblyResolver(allDllPaths);
using var mlc = new MetadataLoadContext(resolver);
var asm = mlc.LoadFromAssemblyPath(System.IO.Path.Combine(gameDlls, "1v1.dll"));

// Inspect PlayerSkins and nested types
foreach (var typeName in new[] { "PlayerSkins", "PlayerSkins+CharSkins", "PlayerSkins+WeaponSkins", "PlayerSkinManager", "SkinPack", "WeaponSkinPack" })
{
    var t = asm.GetTypes().FirstOrDefault(x => x.FullName == typeName || x.Name == typeName);
    Console.WriteLine($"\n=== {typeName} ===");
    if (t == null) { Console.WriteLine("  NOT FOUND"); continue; }
    foreach (var f in t.GetFields(BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Static))
        Console.WriteLine($"  Field: {f.Name} ({f.FieldType.Name}) [static={f.IsStatic}]");
    foreach (var p in t.GetProperties(BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Static))
        Console.WriteLine($"  Prop: {p.Name} ({p.PropertyType.Name})");
    foreach (var m in t.GetMethods(BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Static)
        .Where(m => !m.IsSpecialName))
        Console.WriteLine($"  Method: {m.Name}");
}

// Find PlayerSkinManager – look for methods that deal with equipping
var psm = asm.GetTypes().FirstOrDefault(t => t.Name == "PlayerSkinManager");
if (psm != null)
{
    Console.WriteLine("\n=== PlayerSkinManager All Members ===");
    foreach (var m in psm.GetMethods(BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Static))
        Console.WriteLine($"  Method: {m.Name}({string.Join(", ", m.GetParameters().Select(p => p.ParameterType.Name + " " + p.Name))})");
}
