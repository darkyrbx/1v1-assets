using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using SkinChangerV1.Functions;

using Photon.Pun;
using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using DarkTonic.MasterAudio;

namespace SkinChangerV1.Main
{
    public class Entity : MonoBehaviour
    {
        private int maxTextureSize = 512;
        TextureFormat textureFormat = TextureFormat.ETC2_RGBA8;
        public int poolSize = 10;
        private Queue<GameObject> pool = new Queue<GameObject>();
        public GameObject prefab;
        private float timer;
        public static List<ActionDisplay> ads;
        public static List<WebHudLayoutManager> hud;
        public static List<HotbarSlot> hbs;
        public static List<Image> uii;

        public static List<Animator> animators;
        public static List<Camera> Cameras;
        public static List<TextMeshProUGUI> tmpu;
        public static List<ParticleSystem> ParticleSystems;
        public static List<MasterAudio> audios;
        public static PartyRoomConnector prc;
        
        public void Start()
        {
            Resources.UnloadUnusedAssets();

            // Safely resize textures — skip non-readable ones
            foreach (Texture2D texture2D in Resources.FindObjectsOfTypeAll(typeof(Texture2D)))
            {
                try
                {
                    if (!texture2D.isReadable) continue;
                    int newWidth = Mathf.Max(1, texture2D.width / 10000);
                    int newHeight = Mathf.Max(1, texture2D.height / 10000);
                    Texture2D resizedTexture =
                        new Texture2D(newWidth, newHeight, texture2D.format, texture2D.mipmapCount > 1);

                    Color[] pixels = texture2D.GetPixels(0);
                    Color[] resizedPixels = new Color[newWidth * newHeight];
                    float xRatio = (float)texture2D.width / newWidth;
                    float yRatio = (float)texture2D.height / newHeight;

                    for (int y = 0; y < newHeight; y++)
                    {
                        for (int x = 0; x < newWidth; x++)
                        {
                            int px = Mathf.FloorToInt(x * xRatio);
                            int py = Mathf.FloorToInt(y * yRatio);
                            resizedPixels[y * newWidth + x] = pixels[py * texture2D.width + px];
                        }
                    }

                    resizedTexture.SetPixels(resizedPixels);
                    resizedTexture.Apply();
                    ReplaceTextureInMaterials(texture2D, resizedTexture);
                }
                catch { }
            }

            MeshFilter[] meshFilters = FindObjectsOfType<MeshFilter>();
            foreach (MeshFilter meshFilter in meshFilters)
            {
                try
                {
                    OptimizeMesh(meshFilter);
                    MeshRenderer renderer = meshFilter.GetComponent<MeshRenderer>();
                    if (renderer != null)
                    {
                        renderer.receiveShadows = false;
                        renderer.shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.Off;
                    }
                }
                catch { }
            }

            // Only instantiate from pool if prefab is assigned
            if (prefab != null)
            {
                for (int i = 0; i < poolSize; i++)
                {
                    var obj = Instantiate(prefab);
                    obj.SetActive(false);
                    pool.Enqueue(obj);
                }
            }

            // Initialize list fields to avoid NullRef before first Calls()
            uii = new List<Image>();
            tmpu = new List<TextMeshProUGUI>();
            audios = new List<MasterAudio>();
            ParticleSystems = new List<ParticleSystem>();
            Cameras = new List<Camera>();
        }
        
        
        
        void OptimizeUIElement(CanvasRenderer canvasRenderer)
        {
            Image image = canvasRenderer.GetComponent<Image>();
            if (image != null && image.sprite != null)
            {
                OptimizeSprite(image.sprite);
            }
        }

        void OptimizeSprite(Sprite sprite)
        {
            if (sprite == null) return;

            Texture2D texture = sprite.texture;

            // Create a new texture with the desired settings
            Texture2D optimizedTexture = new Texture2D(
                Mathf.Min(texture.width, maxTextureSize),
                Mathf.Min(texture.height, maxTextureSize),
                textureFormat,
                texture.mipmapCount > 1
            );

            // Copy texture data
            RenderTexture renderTexture = RenderTexture.GetTemporary(
                optimizedTexture.width,
                optimizedTexture.height,
                0,
                RenderTextureFormat.Default,
                RenderTextureReadWrite.Linear
            );

            RenderTexture.active = renderTexture;
            Graphics.Blit(texture, renderTexture);

            optimizedTexture.ReadPixels(new Rect(0, 0, renderTexture.width, renderTexture.height), 0, 0);
            optimizedTexture.Apply();

            RenderTexture.ReleaseTemporary(renderTexture);

            // Create a new sprite with the optimized texture
            Rect rect = sprite.rect;
            Sprite newSprite = Sprite.Create(
                optimizedTexture,
                new Rect(0, 0, optimizedTexture.width, optimizedTexture.height),
                new Vector2(0.5f, 0.5f),
                sprite.pixelsPerUnit,
                0,
                SpriteMeshType.FullRect
            );

            // Replace the sprite's texture with the optimized one
            sprite = newSprite;
        }

        
        void OptimizeMesh(MeshFilter meshFilter)
        {
            Mesh mesh = meshFilter.mesh;
            MeshRenderer meshRenderer = meshFilter.GetComponent<MeshRenderer>();
            if (meshRenderer != null)
            {
                foreach (Material material in meshRenderer.sharedMaterials)
                {
                    Texture mainTexture = material.mainTexture;
                    if (mainTexture != null)
                    {
                        OptimizeTexture((Texture2D)mainTexture);
                    }
                }
            }
        }

        void OptimizeTexture(Texture2D texture)
        {
            if (texture == null) return;

            Texture2D optimizedTexture = new Texture2D(
                Mathf.Min(texture.width, maxTextureSize),
                Mathf.Min(texture.height, maxTextureSize),
                textureFormat,
                texture.mipmapCount > 1
            );

            RenderTexture renderTexture = RenderTexture.GetTemporary(
                optimizedTexture.width,
                optimizedTexture.height,
                0,
                RenderTextureFormat.Default,
                RenderTextureReadWrite.Linear
            );

            RenderTexture.active = renderTexture;
            Graphics.Blit(texture, renderTexture);

            optimizedTexture.ReadPixels(new Rect(0, 0, renderTexture.width, renderTexture.height), 0, 0);
            optimizedTexture.Apply();

            RenderTexture.ReleaseTemporary(renderTexture);
        }
        
        static void ReplaceTextureInMaterials(Texture2D oldTexture, Texture2D newTexture)
        {
            // Find all materials using the old texture and replace it with the new one
            Material[] allMaterials = FindObjectsOfType<Material>();
            foreach (Material mat in allMaterials)
            {
                if (mat.mainTexture == oldTexture)
                {
                    mat.mainTexture = newTexture;
                }
            }
        }

        void Update()
        {
            typeof(QualitySettings).GetProperty("vSyncCount", BindingFlags.Static | BindingFlags.Public)?.SetValue(null, 0);
            if ((bool)Config.Get("FPSCapper"))
            {
                int targetFps = (int)(float)Config.Get("FPSCap");
                if (Application.targetFrameRate != targetFps)
                {
                    Application.targetFrameRate = targetFps;
                }
            }
            else
            {
                if (Application.targetFrameRate != -1)
                {
                    Application.targetFrameRate = -1;
                }
            }

            timer += Time.deltaTime;
            if (timer >= 1.5f)
            {
                if (PhotonNetwork.InRoom && SceneManager.GetActiveScene().name == "MainMenu")
                {
                    tmpu = FindObjectsOfType<TextMeshProUGUI>().ToList();
                }
                Calls();
                
                timer = 0;
            }
        }

        void Calls()
        {
            audios = FindObjectsOfType<MasterAudio>().ToList();
            prc = FindObjectOfType<PartyRoomConnector>();
            ParticleSystems = FindObjectsOfType<ParticleSystem>().ToList();
            if ((bool)Config.Get("SeeUsers"))
            {
                if (!PhotonNetwork.LocalPlayer.CustomProperties.ContainsKey("COUser")) PhotonNetwork.LocalPlayer.CustomProperties.Add("COUser", "true");
            }
            else
            {
                if (PhotonNetwork.LocalPlayer.CustomProperties.ContainsKey("COUser")) PhotonNetwork.LocalPlayer.CustomProperties.Remove("COUser");
                
            }
            
            Config.SaveConfig(Config.filepath);
            
            // Always update UI image list every cycle (needed for HUD disable)
            uii = FindObjectsOfType<Image>().ToList();
            
            if (SceneManager.GetActiveScene().name != "MainMenu" && SceneManager.GetActiveScene().name != "MoveScene")
            {
                Time.fixedDeltaTime = 0.02f; // Set fixed timestep for physics updates

                Cameras = FindObjectsOfType<Camera>().ToList();

                // Guard Camera.main — it can be null during scene transitions
                if (Camera.main != null)
                {
                    Camera.main.farClipPlane = 10000;
                    Camera.main.nearClipPlane = 0.01f;
                }

                Type qualitySettingsType = typeof(QualitySettings);

                PropertyInfo shadowmaskModeProp = qualitySettingsType.GetProperty("shadowmaskMode", BindingFlags.Static | BindingFlags.Public);
                if (shadowmaskModeProp != null)
                {
                    shadowmaskModeProp.SetValue(null, ShadowmaskMode.DistanceShadowmask);
                }

                PropertyInfo maxQueuedFramesProp = qualitySettingsType.GetProperty("maxQueuedFrames", BindingFlags.Static | BindingFlags.Public);
                if (maxQueuedFramesProp != null)
                {
                    maxQueuedFramesProp.SetValue(null, 1);
                }
            }
        }
        
        
        
    }
}
