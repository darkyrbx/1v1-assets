using System.Linq;
using SkinChangerV1Optimizer;
using SkinChangerV1.Utils;
using Photon.Pun;
using UnityEngine;
using Assets.Scripts.Network;
using Photon.Realtime;

namespace SkinChangerV1.Main
{
    public class Menu : MonoBehaviour
    {
        public static bool open = true;
        public static float AmbientHue;
        public static Color baseColor;
        public static Rect mainMenu = new Rect((float)(Screen.width / 2.64), 130f, 320f, 250f);

        private static GUIStyle windowStyle;
        private static Texture2D bgTexture;

        private void Awake()
        {
            Config.LoadConfig(Config.filepath);
            baseColor = GUI.backgroundColor;
            open = true;
        }

        private void Update()
        {
            if (Input.GetKeyDown(KeyCode.RightShift))
            {
                open = !open;
            }
        }

        private static Texture2D MakeTex(int width, int height, Color col)
        {
            Color[] pix = new Color[width * height];
            for (int i = 0; i < pix.Length; i++)
                pix[i] = col;
            Texture2D result = new Texture2D(width, height);
            result.SetPixels(pix);
            result.Apply();
            return result;
        }

        public void OnGUI()
        {
            if (windowStyle == null)
            {
                windowStyle = new GUIStyle(); // Don't copy default window skin to avoid white hover/active states
                
                // Create a completely new sleek dark background texture for the window
                bgTexture = MakeTex(2, 2, new Color(0.07f, 0.08f, 0.09f, 0.98f)); 
                windowStyle.normal.background = bgTexture;
                windowStyle.border.left = 0;
                windowStyle.border.right = 0;
                windowStyle.border.top = 0;
                windowStyle.border.bottom = 0;
            }

            if (open)
            {
                GUI.backgroundColor = Color.white; // reset to avoid tinting the background
                GUIStyle oldStyle = GUI.skin.window;
                GUI.skin.window = windowStyle;
                mainMenu = GUILayout.Window(1, mainMenu, new GUI.WindowFunction(NewMenu), "", new GUILayoutOption[0]);
                GUI.skin.window = oldStyle;
            }
        }

        void NewMenu(int wID)
        {
            GUILayout.Space(20); // Add upper height for spacing
            
            // Draw centered title
            GUIStyle titleStyle = new GUIStyle(GUI.skin.label)
            {
                alignment = TextAnchor.MiddleCenter,
                richText = true
            };
            GUILayout.Label("<b><size=18><color=#b7bdf8>.LOL Skin Changer V1</color></size></b>", titleStyle);
            GUILayout.Space(15);
            
            GuiLib.Begin();
            
            GuiLib.NewSection("General");
            GuiLib.NewButton("Unlock All", UnlockAll);
            
            GuiLib.NewSection("Cosmetics");
            GuiLib.NewButton("Equip Pickaxe: Sci-Fi Hammer", () => AddWeaponSkin("lol.1v1.weaponskins.melee.pickaxe.scifihammer"));
                
            GuiLib.NewSection("Performance");
            Config.Set("FPSCapper", GuiLib.NewToggle((bool)Config.Get("FPSCapper"), "FPS Unlocker / Capper"));
            Config.Set("FPSCap", GuiLib.NewSlider("FPS Cap", (float)Config.Get("FPSCap"), 60, 1000, " FPS"));
            
            GuiLib.End();
            GUILayout.Space(10);

            GUI.DragWindow();
        }

        void AddWeaponSkin(string skin)
        {
            if (FirebaseManager.Instance.JLPGEKNJLMG == null) return;
            var skins = FirebaseManager.Instance.JLPGEKNJLMG.Skins;
            
            if (!skins.WeaponSkins.Contains(skin))
            {
                skins.WeaponSkins.Add(skin);
            }

            string weaponType = string.Join(".", skin.Split('.').Take(4));
            skins.EquippedWeaponSkins.RemoveAll(s => s.ToLower().StartsWith(weaponType.ToLower()));
            skins.EquippedWeaponSkins.Add(skin);
        }

        void UnlockAll()
        {
            var serverUser = FirebaseManager.Instance.JLPGEKNJLMG;
            if (serverUser == null) return;

            var skins = serverUser.Skins;

            for (int i = 1; i <= 288; i++)
            {
                string id = "lol.1v1.playerskins.pack." + i;
                if (!skins.CharacterSkins.Contains(id))
                    skins.CharacterSkins.Add(id);
            }

            foreach (var namedSkin in GameVars.ChampionSkins)
            {
                if (!skins.CharacterSkins.Contains(namedSkin))
                    skins.CharacterSkins.Add(namedSkin);
            }

            for (int i = 1; i <= 100; i++)
            {
                string emote = "lol.1v1.playeremotes.pack." + i;
                if (!skins.OwnedEmotes.Contains(emote))
                    skins.OwnedEmotes.Add(emote);
            }

            for (int i = 1; i <= 100; i++)
            {
                string sticker = "lol.1v1.playerstickers.pack." + i;
                if (!skins.OwnedEmotes.Contains(sticker))
                    skins.OwnedEmotes.Add(sticker);
            }

            if (serverUser.Equipment != null && serverUser.Equipment.Equipment != null)
            {
                foreach (var champ in new[]
                {
                    "lol.1v1.champions.violet",
                    "lol.1v1.champions.magma",
                    "lol.1v1.champions.caesar",
                    "lol.1v1.champions.frosty",
                    "lol.1v1.champions.shadow",
                    "lol.1v1.champions.jade",
                    "lol.1v1.champions.tron",
                    "lol.1v1.champions.sentinel",
                    "lol.1v1.champions.fang",
                    "lol.1v1.champions.poseidon",
                    "lol.1v1.champions.ladypop"
                })
                {
                    if (!serverUser.Equipment.Equipment.ContainsKey(champ))
                        serverUser.Equipment.Equipment.Add(champ, new UserUpgradeableItem() { Level = 1 });
                }
            }
        }
    }
}
