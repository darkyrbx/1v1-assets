using SkinChangerV1.Functions;
using SkinChangerV1.Main;
using UnityEngine;

namespace SkinChangerV1
{
    public class Loader
    {
        static GameObject go;

        public static void Load()
        {
            go = new GameObject("SkinChangerV1 Optimizer");
            go.AddComponent<Menu>();
            go.AddComponent<Entity>();
            go.AddComponent<Misc>();
            UnityEngine.Object.DontDestroyOnLoad(go);
        }

        public static void Unload()
        {
            UnityEngine.Object.Destroy(go);
        }
    }
}
