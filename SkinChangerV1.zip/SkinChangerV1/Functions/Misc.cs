using System.Reflection;
using Photon.Pun;
using UnityEngine;
using UnityEngine.SceneManagement;
using System;
using System.Runtime.CompilerServices;
using UnityEngine.Bindings;
using UnityEngine.Internal;
using UnityEngine.Rendering;
using System;
using System.Collections.Generic;
using System.IO;
using SkinChangerV1.Main;
using Photon.Pun;
using Assets.Scripts.Network;
using Photon.Realtime;
using SkinChangerV1.Utils;
using ExitGames.Client.Photon.StructWrapping;
using Newtonsoft.Json;
using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace SkinChangerV1.Functions 
{
    public class Misc : MonoBehaviour
    {

        public static List<string> COUsers = new List<string>();
        public static float hue;
        public static float sat = .35f;
        public static float bri = 1f;

        public static List<string> Builds = new List<string>()
        {
            "Wall",
            "Floor",
            "Ramp",
            "Pyramid",
            "Roof"
        };
        

        private float hudTimer = 0f;
        private float photontimer = 0f; // Without this your lobby bugs out big time
        
        public void OnGUI()
        {
           
            if ((bool)Config.Get("Ambient") && GameVars.LocalPlayer() != null)
            {
                Ambient();
            }

            if ((bool)Config.Get("Crosshair"))
            {
                Crosshair();
            }
        }

        

        void Crosshair()
        {
            GUI.DrawTexture(new Rect(Render.CenterOfScreen().x - 15f, Render.CenterOfScreen().y, 30f, 2f), Texture2D.whiteTexture);
            GUI.DrawTexture(new Rect(Render.CenterOfScreen().x, Render.CenterOfScreen().y - 15f, 2f, 30f), Texture2D.whiteTexture);
        }

       
        
        
        public void Update()
        {
            if ((bool)Config.Get("DisableAllAudio") && Entity.audios != null)
            {
                foreach (var audio in Entity.audios)
                {
                    if (audio == null) continue;
                    audio.enabled = false;
                    audio.gameObject.SetActive(false);
                }
            }
            if ((bool)Config.Get("DisableParticles") && Entity.ParticleSystems != null)
            {
                foreach (var ps in Entity.ParticleSystems)
                {
                    if (ps == null) continue;
                    if (ps.isPlaying)
                    {
                        ps.Stop();
                    }
                }
            }
            if (PhotonNetwork.InRoom && SceneManager.GetActiveScene().name == "MainMenu")
            {
                photontimer += Time.deltaTime;
                if (photontimer >= 1.75f)
                {
                    foreach (var p in PhotonNetwork.PlayerList)
                    {
                        if (p.CustomProperties.ToString().Contains("COUser") && !COUsers.Contains(p.NickName))
                        {
                            COUsers.Add(p.NickName);
                        }
                    }

                    if (Entity.tmpu != null)
                    {
                        foreach (var tmp in Entity.tmpu)
                        {
                            if (tmp == null) continue;
                            if (COUsers.Contains(tmp.text) && !tmp.text.Contains("[CO]"))
                            {
                                tmp.text = "[CO] " + tmp.text;
                            }
                        }
                    }

                    photontimer = 0f;
                }
            }
            // uwu
            if (SceneManager.GetActiveScene().name != "MainMenu" &&
                SceneManager.GetActiveScene().name != "MoveScene")
            {
                
                hudTimer += Time.deltaTime;
                if (hudTimer >= 1.75f)
                {
                    if (Entity.uii != null)
                    {
                        foreach (var uie in Entity.uii)
                        {
                            if (uie == null) continue;
                            if (uie.name == null) continue;

                            // Disable Entire HUD
                            if ((bool)Config.Get("DisableHud"))
                            {
                                if (uie.enabled) uie.enabled = false;
                                uie.gameObject.SetActive(false);
                            }

                            if ((bool)Config.Get("AestheticKeys"))
                            {
                                if (uie.name == "Bg")
                                {
                                    if (uie.enabled) uie.enabled = false;
                                    uie.gameObject.SetActive(false);
                                }
                            }

                            if (Builds.Contains(uie.name))
                            {
                                // Disable Builds
                                if ((bool)Config.Get("DisableBuilds"))
                                {
                                    if (uie.enabled) uie.enabled = false;
                                    uie.gameObject.SetActive(false);
                                }
                            }

                            if (uie.name.Contains("Slot") || uie.name == "Container")
                            {
                                if ((bool)Config.Get("DisableSlots"))
                                {
                                    if (uie.enabled) uie.enabled = false;
                                    uie.gameObject.SetActive(false);
                                }
                            }

                            if (uie.name == "Health" || uie.name == "Armor" || uie.name == "DecreaseEffect" ||
                                uie.name == "darkener" || uie.name == "Background" || uie.name == "HealthGlow")
                            {
                                if ((bool)Config.Get("DisableHealth"))
                                {
                                    if (uie.enabled) uie.enabled = false;
                                    uie.gameObject.SetActive(false);
                                }
                            }
                        }
                    }

                    hudTimer = 0f;
                }
            }
        }
            
            
            
            
        
    


       
        
        public static void Ambient()
        {
            if (SceneManager.GetActiveScene().name != "MainMenu" && SceneManager.GetActiveScene().name != "MoveScene")
            {
                if (Entity.Cameras == null || Entity.Cameras.Count == 0)
                {
                    Entity.Cameras = new List<Camera>(FindObjectsOfType<Camera>());
                }
                foreach (Camera camera in Entity.Cameras)
                {
                    if (camera == null) continue;
                    switch ((int)Config.Get("AmbientMode"))
                    {
                        case 0:
                            camera.clearFlags = CameraClearFlags.Color;
                            camera.backgroundColor = Util.GetColorFromString(Config.Get("SkyColor1").ToString());
                            break;
                        case 1:
                            camera.clearFlags = CameraClearFlags.Color;
                            camera.backgroundColor = Color.Lerp(
                                Util.GetColorFromString(Config.Get("SkyColor2").ToString()),
                                Util.GetColorFromString(Config.Get("SkyColor3").ToString()),
                                Mathf.PingPong(Time.time * (float)Config.Get("LerpSpeed"), 1f));
                            break;
                        case 2:
                            // Use Time.deltaTime so RGB speed is frame-rate independent
                            float rainbowSpeed = (float)Config.Get("AmbientRainbowSpeed");
                            Menu.AmbientHue += Time.deltaTime * rainbowSpeed * 0.15f;
                            if (Menu.AmbientHue >= 1f) Menu.AmbientHue = 0f;
                            camera.clearFlags = CameraClearFlags.Color;
                            camera.backgroundColor = Color.HSVToRGB(Menu.AmbientHue, sat, bri);
                            break;
                    }
                }
            }
        }
    }
}
